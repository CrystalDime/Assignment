﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace WcfServiceLibrary1
{
        public class Service1 : IService1
    {
        public String GetData(string value)
        {
            //Oracle Database connection with connection string. Replace with your own.
            OracleConnection cn = new OracleConnection("Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = 10.127.228.58)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = XE))); User Id=SYSTEM;Password=password;");
            cn.Open();
            
            string[] typeofcmd = value.Split('|');
          
            OracleCommand cmd = cn.CreateCommand();
            cmd.CommandText = typeofcmd[0];
            OracleDataReader reader;
            
            if (typeofcmd[1] == "p")
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(":q", OracleDbType.RefCursor, ParameterDirection.Output);
                if (typeofcmd.GetLength(0) > 2)
                {
                    // Maybe add loop to add any parameters
                    cmd.Parameters.Add(":GenreS", OracleDbType.Char, ParameterDirection.Input).Value = typeofcmd[2];
                }
                cmd.ExecuteNonQuery();
                OracleRefCursor curr = (OracleRefCursor)cmd.Parameters[0].Value;
                reader = curr.GetDataReader();
            }
            else
            {
                reader = cmd.ExecuteReader();
            }
           

            String baseString = "";
            StringBuilder sb;
            while (reader.Read())
            {
                
                for (int i = 0; i < 7; i++)
                {
                    baseString += (reader.GetString(i)) + ":";
                  
                }
                 
                sb = new StringBuilder(baseString);
                sb.Remove(baseString.Length - 1, 1);
                baseString = sb.ToString();
                baseString += "/";
            }
            sb = new StringBuilder(baseString);
            sb.Remove(baseString.Length - 1, 1);
            baseString = sb.ToString();
            return baseString;
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
