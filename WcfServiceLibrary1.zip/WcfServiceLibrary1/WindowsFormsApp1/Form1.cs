﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            String textSelected = comboBox1.Text;
            ServiceReference1.Service1Client client = new
           ServiceReference1.Service1Client();

            String resultant = client.GetData("SelectGenre|p|" + textSelected);
            System.Diagnostics.Debug.WriteLine(resultant + "\n");
            string[] rows = resultant.Split('/');
            string[,] array = new string[rows.GetLength(0), 10];
            int row_index = 0;
            int column_index = 0;
            foreach (string x in rows)
            {
                string[] columns = x.Split(':');
                foreach (string y in columns)
                {
                    array[row_index, column_index] = y;
                    column_index++;
                }

                column_index = 0;
                row_index++;

            }
            this.setData(array);

        }

        private void Form1_Load(object sender, EventArgs S)
        {
            /*
            var Grid = dataGridView1;

            Grid.ColumnCount = 3;
            Grid.Columns[0].Name = "Name";
            Grid.Columns[1].Name= "Genre";
            Grid.Columns[2].Name = "Rating";
            //*/
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new
            ServiceReference1.Service1Client();

            String resultant = client.GetData("SELECT * FROM MY_BOOKS|t");
            System.Diagnostics.Debug.WriteLine(resultant + "\n");
            string[] rows = resultant.Split('/');
            string[,] array = new string[rows.GetLength(0), 10];
            int row_index = 0;
            int column_index = 0;
            foreach (string x in rows)
            {
                string[] columns = x.Split(':');
                foreach (string y in columns)
                {
                    array[row_index, column_index] = y;
                    column_index++;
                }

                column_index = 0;
                row_index++;

            }
            this.setData(array);
            /*
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    System.Diagnostics.Debug.Write(array[i, j] + "    ");
                }
                System.Diagnostics.Debug.WriteLine("\n");
            }
            */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            ServiceReference1.Service1Client client = new
            ServiceReference1.Service1Client();

            String resultant = client.GetData("SELECT * FROM MY_BOOKS|t");
            System.Diagnostics.Debug.WriteLine(resultant + "\n");
            string[] rows = resultant.Split('/');
            string[,] array = new string[rows.GetLength(0), 10];
            int row_index = 0;
            int column_index = 0;
            foreach (string x in rows)
            {
                string[] columns = x.Split(':');
                foreach(string y in columns)
                {
                    array[row_index, column_index] = y;
                    column_index++;
                }

                column_index = 0;
                row_index++;

            }

            this.setData(array);
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new
            ServiceReference1.Service1Client();

            String resultant = client.GetData("SelectAllPopular|p");
             System.Diagnostics.Debug.WriteLine(resultant + "\n");
            string[] rows = resultant.Split('/');
            string[,] array = new string[rows.GetLength(0), 10];
            int row_index = 0;
            int column_index = 0;
            foreach (string x in rows)
            {
                string[] columns = x.Split(':');
                foreach (string y in columns)
                {
                    array[row_index, column_index] = y;
                    column_index++;
                }

                column_index = 0;
                row_index++;

            }
            this.setData(array);

            /*
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    System.Diagnostics.Debug.Write(array[i, j] + "    ");
                }
                System.Diagnostics.Debug.WriteLine("\n");
            }
            */

        }
        private void button3_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new
            ServiceReference1.Service1Client();

            String resultant = client.GetData("SelectBestRated|p");
            System.Diagnostics.Debug.WriteLine(resultant + "\n");
            string[] rows = resultant.Split('/');
            string[,] array = new string[rows.GetLength(0), 10];
            int row_index = 0;
            int column_index = 0;
            foreach (string x in rows)
            {
                string[] columns = x.Split(':');
                foreach (string y in columns)
                {
                    array[row_index, column_index] = y;
                    column_index++;
                }

                column_index = 0;
                row_index++;

            }
            this.setData(array);

            /*
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    System.Diagnostics.Debug.Write(array[i, j] + "    ");
                }
                System.Diagnostics.Debug.WriteLine("\n");
            }
            */

        }
        private void setData(String[,] input)
        {
            var Grid = dataGridView1;

            Grid.RowCount = input.GetLength(0);
            for (int i = 0; i < input.GetLength(0); i++)
            {

                Grid.Rows[i].Cells[0].Value = input[i, 0];
                Grid.Rows[i].Cells[1].Value = input[i, 1];
                Grid.Rows[i].Cells[2].Value = input[i, 4];
                Grid.Rows[i].Cells[3].Value = input[i, 5];
                Grid.Rows[i].Cells[4].Value = input[i, 6];
               

            }


        }
        private void datagridview_SelectionChanged(object sender, EventArgs e)
        {
            this.dataGridView1.ClearSelection();
        }
    }
}
